/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>

// Assuming these functions are implemented in your code
unsigned int READ_CYCLE_COUNTER();
int READ_MOTOR_RPM();
void log(float value);

int main() {
    // Constants
    float CPU_FREQ = 100000000.0;  // Replace with your actual CPU frequency
    float T_s = 0.01;  // Replace with your desired sampling period
    float time = 10.0;  // Replace with your desired total runtime
    float k_p = 0.1;  // Replace with your proportional gain
    float k_d = 0.01;  // Replace with your derivative gain
    float k_i = 0.001;  // Replace with your integral gain

    // Variables
    float error = 0.0;
    float error_old = 0.0;
    float error_accum = 0.0;
    float error_delta = 0.0;
    float motor_input = 0.0;
    unsigned int cycle_counter = 0;
    unsigned int prev_control_action_cycles = 0;
    float time_since_last_control = 0.0;
    float time_since_start = 0.0;

    while (1) {
        // Determine if we should perform control
        cycle_counter = READ_CYCLE_COUNTER();
        unsigned int cycles_since_last_control = cycle_counter - prev_control_action_cycles;
        time_since_last_control = cycles_since_last_control / CPU_FREQ;
        time_since_start = cycle_counter / CPU_FREQ;

        // Perform control
        if (time_since_last_control >= T_s) {
            int current_motor_rpm = READ_MOTOR_RPM();

            error_old = error;
            error = current_motor_rpm - setpoint;
            error_accum += error;
            error_delta = error - error_old;

            motor_input = k_p * error + k_d * error_delta + k_i * error_accum;

            // Log time_since_start, motor_input, current_motor_rpm
            log(time_since_start);
            log(motor_input);
            log(current_motor_rpm);

            prev_control_action_cycles = cycle_counter;

            // Check if the specified time has elapsed
            if (time_since_start > time) {
                break;
            }
        }
    }

    return 0;
}
